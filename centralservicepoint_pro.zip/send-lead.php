<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$service=$_POST['service'];
$message=$_POST['message'];

$to="yourbusiness@email.com";
$subject="New Lead From Central Service Point";
$body="Name: $name\nEmail: $email\nPhone: $phone\nService: $service\nMessage: $message";
$headers="From: noreply@centralservicepoint.store";

mail($to,$subject,$body,$headers);
header("Location: thank-you.html");
}
?>
